'use strict';

/**
 * @ngdoc service
 * @name coffeeCartApp.firebaseCrud
 * @description
 * # firebaseCrud
 * Service in the coffeeCartApp.
 */
angular.module('coffeeCartApp')
  .service('firebaseCrud', ['$firebase', function firebaseCrud($firebase) {

  	return {

  		saveEnquiry: function () {
  		}
  	};

  }]);
